﻿using System.ComponentModel.DataAnnotations;

namespace BorrowBook.Models
{
    public class EmprestimosModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Type the borrower's Name!")]
        public string Recebedor { get; set; }

        [Required(ErrorMessage = "Type the Lenders's Name!")]
        public string Fornecedor { get; set; }

        [Required(ErrorMessage = "Type the Book's Name!")]
        public string LivroEmprestado { get; set; }

        public DateTime dataUltimaAtualizacao { get; set; } = DateTime.Now;
    }
}
